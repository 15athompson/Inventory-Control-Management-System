import org.junit.Test;
import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
import java.math.BigDecimal;

import static org.junit.Assert.*;

public class StoreTest {

    
    // Test if the method can read the transactions file correctly and add transactions to the transactions list.
    @Test
    public void testGenerateReportTransactions() {
        File transactionsFile = new File("test_transactions.csv");
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item(0, "Item 1", null, 10));
        items.add(new Item(0, "Item 2", null, 20));
        Store.generateReport(transactionsFile, items);
        ArrayList<Transaction> transactions = Store.getTransactions();
        assertEquals(2, transactions.size());
        assertEquals("Item 1", transactions.get(0).getDescription());
        assertEquals(5, transactions.get(0).getStockRemaining());
        assertEquals("Item 2", transactions.get(1).getDescription());
        assertEquals(15, transactions.get(1).getStockRemaining());
    }

    private void assertEquals(int i, int size) {
    }

    // Test if the method can filter transactions by today's date correctly.
    @Test
    public void testGenerateReportTodayTransactions() {
        File transactionsFile = new File("test_transactions.csv");
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item(0, "Item 1", null, 10));
        items.add(new Item(0, "Item 2", null, 20));
        Store.generateReport(transactionsFile, items);
        ArrayList<Transaction> todayTransactions = Store.getTodayTransactions();
        assertEquals(1, todayTransactions.size());
        assertEquals(LocalDate.now(), todayTransactions.get(0).getTransactionDate());
    }

    // Test if the method can update the stock of the items correctly.
    @Test
    public void testGenerateReportStockUpdate() {
        File transactionsFile = new File("test_transactions.csv");
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item(0, "Item 1", null, 10));
        items.add(new Item(0, "Item 2", null, 20));
        Store.generateReport(transactionsFile, items);
        assertEquals(5, items.get(0).getStock());
        assertEquals(15, items.get(1).getStock());
    }

    // Test if the method can handle insufficient stock correctly.
    @Test
    public void testGenerateReportInsufficientStock() {
        File transactionsFile = new File("test_transactions_insufficient_stock.csv");
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item(0, "Item 1", null, 5));
        Store.generateReport(transactionsFile, items);
        ArrayList<Transaction> transactions = Store.getTransactions();
        assertEquals(0, transactions.size());
        assertEquals(5, items.get(0).getStock());
    }

    // Test if the method can handle invalid transactions in the input file correctly.
    @Test
    public void testGenerateReportInvalidTransactions() {
        File transactionsFile = new File("test_transactions_invalid.csv");
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item(0, "Item 1", null, 10));
        Store.generateReport(transactionsFile, items);
        ArrayList<Transaction> transactions = Store.getTransactions();
        assertEquals(0, transactions.size());
        assertEquals(10, items.get(0).getStock());
    }
    
    

    








    private static void searchItem(ArrayList<Item> items1) {
    }

    private void assertEquals(LocalDate localDate, LocalDate localDate2) {
    }

    private void assertEquals(int i, String stockRemaining) {
    }

    private void assertEquals(String string, String string2) {
    }

    



    
}

/*
testGenerateReportTransactions:

Input:
A file containing the following transactions:

Item 1,2023-04-26,5
Item 2,2023-04-26,5

An ArrayList of Item objects containing:

Item 1 (initial stock: 10)
Item 2 (initial stock: 20)

Output:
An ArrayList of Transaction objects containing:

Transaction 1: Item 1, 2023-04-26, 5 (stock remaining: 5)
Transaction 2: Item 2, 2023-04-26, 5 (stock remaining: 15)

The method should update the stock of Item 1 to 5 and Item 2 to 15.

---------------------------------------------------------------------
testGenerateReportTodayTransactions:

Input:
A file  containing the following transactions:


Item 1,2023-04-25,5
Item 2,2023-04-26,5

An ArrayList of Item objects containing:

Item 1 (initial stock: 10)
Item 2 (initial stock: 20)
Output:

An ArrayList of Transaction objects containing:

Transaction 1: Item 2, 2023-04-26, 5 (stock remaining: 15)

The method should update the stock of Item 1 to 10 and Item 2 to 15.

---------------------------------------------------------------------

testGenerateReportStockUpdate:

Input:
A file containing the following transactions:

Item 1,2023-04-26,5
Item 2,2023-04-26,5

An ArrayList of Item objects containing:

Item 1 (initial stock: 10)
Item 2 (initial stock: 20)

Output:
The stock of Item 1 should be updated to 5 and the stock of Item 2 should be updated to 15.

---------------------------------------------------------------------

testGenerateReportInsufficientStock:

Input:
A file containing the following transactions:

Item 1,2023-04-26,10

An ArrayList of Item objects containing:

Item 1 (initial stock: 5)

Output:
The method should not add any transactions to the ArrayList of Transaction objects and the stock of Item 1 should remain at 5.

---------------------------------------------------------------------

testGenerateReportInvalidTransactions:

Input:
A file containing the following transactions:

Item 1,2023-04-26,abc

An ArrayList of Item objects containing:

Item 1 (initial stock: 10)

Output:
The method should not add any transactions to the ArrayList of Transaction objects and the stock of Item 1 should remain at 1 */