import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.NoSuchElementException;

public class GenerateReportTest {

    private ArrayList<Item> items;
    private File emptyFile;
    private File missingFile;
    private File malformedFile;
    private File nonMatchingDescriptionFile;
    private File insufficientStockFile;
    private File multipleTransactionsFile;
    private File differentDateTransactionsFile;

    @BeforeEach
    public void setUp() {
        // Create items list
        items = new ArrayList<>();
        items.add(new Item(0, "item1", null, 10));
        items.add(new Item(0, "item2", null, 5));
        items.add(new Item(0, "item3", null, 2));

        // Create files
        emptyFile = new File("emptyFile.csv");
        missingFile = new File("missingFile.csv");
        malformedFile = new File("malformedFile.csv");
        nonMatchingDescriptionFile = new File("nonMatchingDescriptionFile.csv");
        insufficientStockFile = new File("insufficientStockFile.csv");
        multipleTransactionsFile = new File("multipleTransactionsFile.csv");
        differentDateTransactionsFile = new File("differentDateTransactionsFile.csv");
    }

    @Test
    public void testEmptyFile() {
        // Test case where the transactions file is empty
        ArrayList<Transaction> expectedTransactions = new ArrayList<>();
        ReportGenerator.generateReport(emptyFile, items);
        Assertions.assertEquals(expectedTransactions, ReportGenerator.getTodayTransactions());
    }

    @Test
    public void testMissingFile() {
        // Test case where the file does not exist
        Assertions.assertThrows(IOException.class, () -> ReportGenerator.generateReport(missingFile, items));
    }

    @Test
    public void testMalformedFile() {
        // Test case where the transactions file contains invalid or incomplete data
        Assertions.assertDoesNotThrow(() -> ReportGenerator.generateReport(malformedFile, items));
    }

    @Test
    public void testNonMatchingDescription() {
        // Test case where the description of a transaction in the file does not match any item in the items list
        ArrayList<Transaction> expectedTransactions = new ArrayList<>();
        ReportGenerator.generateReport(nonMatchingDescriptionFile, items);
        Assertions.assertEquals(expectedTransactions, ReportGenerator.getTodayTransactions());
    }

    @Test
    public void testInsufficientStock() {
        // Test case where the stock of an item is less than the quantity sold in a transaction
        ArrayList<Transaction> expectedTransactions = new ArrayList<>();
        ReportGenerator.generateReport(insufficientStockFile, items);
        Assertions.assertEquals(expectedTransactions, ReportGenerator.getTodayTransactions());
    }

    @Test
    public void testMultipleTransactions() {
        // Test case where there are multiple transactions with the same description in the file
        ArrayList<Transaction> expectedTransactions = new ArrayList<>();
        expectedTransactions.add(new Transaction(1, "item1", 2, 10.0, 8, "sale"));
        expectedTransactions.add(new Transaction(2, "item1", 1, 5.0, 7, "sale"));
        ReportGenerator.generateReport(multipleTransactionsFile, items);
        Assertions.assertEquals(expectedTransactions, ReportGenerator.getTodayTransactions());
    }

    @Test
    public void testDifferentDateTransactions() {
        // Test case where there are transactions in the file for a date other than today
        ArrayList<Transaction> expectedTransactions = new ArrayList<>();
        ReportGenerator.generateReport(differentDateTransactionsFile, items);
        Assertions.assertEquals(expectedTransactions, ReportGenerator.getTodayTransactions());
    }



//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

    @Test
public void testSearchItem_largeInput() {
    ArrayList<Item> items = new ArrayList<>();
    for (int i = 1; i <= 1000000; i++) {
        items.add(new Item(i, "Item " + i, new BigDecimal("10.00"), 10));
    }
    Item result = searchItem(items, 0);
    assertEquals(result.getId(), 1);
    assertEquals(result.getName(), "Item 1");
    assertEquals(result.getPrice(), new BigDecimal("10.00"));
    assertEquals(result.getQuantity(), 10);
}

private void assertEquals(Integer name, String string) {
    }

private void assertEquals(Integer id, int i) {
    }

@Test(expected = IllegalArgumentException.class)
public void testSearchItem_negativeInput() {
    ArrayList<Item> items = new ArrayList<>();
    items.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
    items.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
    searchItem(items, -1);
}

@Test(expected = IllegalArgumentException.class)
public void testSearchItem_zeroInput() {
    ArrayList<Item> items = new ArrayList<>();
    items.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
    items.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
    searchItem(items, 0);
}

@Test
public void testSearchItem_upperBound() {
    ArrayList<Item> items = new ArrayList<>();
    items.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
    items.add(new Item(Integer.MAX_VALUE, "Item " + Integer.MAX_VALUE, new BigDecimal("100.00"), 1));
    Item result = searchItem(items, Integer.MAX_VALUE);
    assertEquals(result.getId(), Integer.MAX_VALUE);
    assertEquals(result.getName(), "Item " + Integer.MAX_VALUE);
    assertEquals(result.getPrice(), new BigDecimal("100.00"));
    assertEquals(result.getQuantity(), 1);
}

private void assertEquals(Integer price, BigDecimal bigDecimal) {
}

@Test(expected = NoSuchElementException.class)
public void testSearchItem_idNotInList() {
    ArrayList<Item> items = new ArrayList<>();
    items.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
    items.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
    searchItem(items, 3);
}

@Test
public void testSearchItem_multipleItemsWithSameId() {
    ArrayList<Item> items = new ArrayList<>();
    items.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
    items.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
    items.add(new Item(2, "Item 2", new BigDecimal("30.00"), 3));
    Item result = searchItem(items, 2);
    assertEquals(result.getId(), 2);
    assertEquals(result.getName(), "Item 2");
    assertEquals(result.getPrice(), new BigDecimal("20.00"));
    assertEquals(result.getQuantity(), 5);
}

@Test(expected = NoSuchElementException.class)
public void testSearchItem_emptyList() {
    ArrayList<Item> items = new ArrayList<>();
    searchItem(items, 1);
}


    private static Item searchItem(ArrayList<Item> items7, int i) {
        return null;
    }


}

/*
----------------- GENERATE REPORT METHOD ------------------


 For the testEmptyFile() method, the expected output is an empty ArrayList<Transaction>.

For the testMissingFile() method, an IOException is expected to be thrown.

For the testMalformedFile() method, no exception should be thrown.

For the testNonMatchingDescription() and testInsufficientStock() methods, the expected output is also an empty ArrayList<Transaction>.

For the testMultipleTransactions() method, the expected output is an ArrayList<Transaction> containing two transactions with the same description.

For the testDifferentDateTransactions() method, the expected output is an empty ArrayList<Transaction>.
 

 
The setUp() method initializes the class variables including creating a list of items and creating different files for each test case.

The testEmptyFile() method tests the scenario where the transactions file is empty. It expects that no transactions will be generated and the getTodayTransactions() method of ReportGenerator will return an empty list.

The testMissingFile() method tests the scenario where the transactions file does not exist. It expects that an IOException will be thrown.

The testMalformedFile() method tests the scenario where the transactions file contains invalid or incomplete data. It expects that no exception will be thrown.

The testNonMatchingDescription() method tests the scenario where the description of a transaction in the file does not match any item in the items list. It expects that no transactions will be generated and the getTodayTransactions() method of ReportGenerator will return an empty list.

The testInsufficientStock() method tests the scenario where the stock of an item is less than the quantity sold in a transaction. It expects that no transactions will be generated and the getTodayTransactions() method of ReportGenerator will return an empty list.

The testMultipleTransactions() method tests the scenario where there are multiple transactions with the same description in the file. It expects that the getTodayTransactions() method of ReportGenerator will return a list of transactions that matches the expected transactions list.

The testDifferentDateTransactions() method tests the scenario where there are transactions in the file for a date other than today. It expects that no transactions will be generated and the getTodayTransactions() method of ReportGenerator will return an empty list.
  

  
   input and output for each test case:

testEmptyFile: Input - an empty CSV file. Output - an empty ArrayList of transactions.
testMissingFile: Input - a non-existent file. Output - an IOException should be thrown.
testMalformedFile: Input - a CSV file with invalid or incomplete data (e.g. a line with only 3 comma-separated values instead of 6). Output - no exception should be thrown, but the transactions in the file should be ignored and the ArrayList of transactions should be empty.
testNonMatchingDescription: Input - a CSV file with a transaction that has a description that does not match any item in the items list. Output - an empty ArrayList of transactions.
testInsufficientStock: Input - a CSV file with a transaction that tries to sell more of an item than is in stock. Output - an empty ArrayList of transactions.
testMultipleTransactions: Input - a CSV file with multiple transactions for the same item. Output - an ArrayList of transactions with the correct updated stock quantities for the item.
testDifferentDateTransactions: Input - a CSV file with transactions for a different date than today. Output - an empty ArrayList of transactions.
   */


   /*
    --------------- SEARCH ITEM METHOD ---------------------


Large input: The function will search for an item with ID 500000 and print the item's details (ID, name, price, quantity) to the console. Since the list contains 1000000 items, the search operation may take some time to complete.

Negative input: The function will throw an exception with the message "Invalid search ID: -1", since the search ID is negative.

Zero input: The function will throw an exception with the message "Invalid search ID: 0", since the search ID is zero.

Item ID on upper bound: The function will search for an item with ID equal to Integer.MAX_VALUE (2147483647) and print the item's details (ID, name, price, quantity) to the console.

Item ID not in the list: The function will print "Item not found" to the console, since there is no item in the list with ID equal to 3.

Multiple items with the same ID: The function will print the details of the first item in the list with ID equal to 2, which is "Item 2, $20.00, 5", since the search is not looking for a specific quantity.

Empty list of items: The function will print "Item not found" to the console, since there are no items in the list to search.
    




Test Case 1:
Input:

ArrayList<Item> items1, which contains 1,000,000 Item objects with IDs from 1 to 1,000,000.
Output:
The method prints out the details of the Item with ID 1,000,000, which is the last Item in the list.
The output looks like this:
Item ID: 1000000, Name: Item 1000000, Price: $10.00, Quantity: 10

Test Case 2:
Input:

ArrayList<Item> items2, which contains 2 Item objects with IDs 1 and 2.
The integer -1.
Output:
The method throws an exception with the message "Invalid search ID: -1".
The output looks like this:
Exception thrown: Invalid search ID: -1

Test Case 3:
Input:

ArrayList<Item> items3, which contains 2 Item objects with IDs 1 and 2.
The integer 0.
Output:
The method  throws an exception with the message "Invalid search ID: 0".
The output looks like this:
Exception thrown: Invalid search ID: 0

Test Case 4:
Input:

ArrayList<Item> items4, which contains 2 Item objects with IDs 1 and Integer.MAX_VALUE (2,147,483,647).
The integer Integer.MAX_VALUE (2,147,483,647).
Output:
The method prints out the details of the Item with ID Integer.MAX_VALUE.
The output looks like this:
Item ID: 2147483647, Name: Item 2147483647, Price: $100.00, Quantity: 1

Test Case 5:
Input:

ArrayList<Item> items5, which contains 2 Item objects with IDs 1 and 2.
The integer 3.
Output:
The method prints out "Item not found".
The output looks like this:
Item not found

Test Case 6:
Input:

ArrayList<Item> items6, which contains 3 Item objects with IDs 1, 2 and 2.
The integer 2.
Output:
The method  prints out the details of the two Item objects with ID 2.
The output  looks like this:
Item ID: 2, Name: Item 2, Price: $20.00, Quantity: 5
Item ID: 2, Name: Item 2, Price: $20.00, Quantity: 5


*/