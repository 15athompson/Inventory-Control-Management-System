import java.math.BigDecimal;




/**
 * Represents an item in a store.
 */

public class itemUnitTest {
    
    private int id;
    private String description;
    private BigDecimal unitPrice;
    private int qtyInStock;
    private BigDecimal totalPrice;

    /**
     * Constructs an item with the specified ID, description, unit price, and quantity in stock.
     * 
     * @param id the ID of the item
     * @param description the description of the item
     * @param unitPrice the unit price of the item
     * @param qtyInStock the quantity of the item in stock
     */
    public Item(int id, String description, BigDecimal unitPrice, int qtyInStock) {
        this.id = id;
        this.description = description;
        this.unitPrice = unitPrice;
        this.qtyInStock = qtyInStock;
        this.totalPrice = unitPrice.multiply(new BigDecimal(qtyInStock));
    }

    /**
     * Constructs an item with the specified ID, description, unit price, quantity in stock, and total price.
     * 
     * @param id the ID of the item
     * @param description the description of the item
     * @param unitPrice the unit price of the item
     * @param qtyInStock the quantity of the item in stock
     * @param totalPrice the total price of the item
     */
    public Item(int id, String description, BigDecimal unitPrice, int qtyInStock, BigDecimal totalPrice) {
        this.id = id;
        this.description = description;
        this.unitPrice = unitPrice;
        this.qtyInStock = qtyInStock;
        this.totalPrice = totalPrice;
    }

    /**
     * Returns the ID of the item.
     * 
     * @return the ID of the item
     */
    public int getId() {
        return id;
    }

    /**
     * Returns the description of the item.
     * 
     * @return the description of the item
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description of the item.
     * 
     * @param description the new description of the item
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the unit price of the item.
     * 
     * @return the unit price of the item
     */
    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the unit price of the item and updates the total price of the item.
     * 
     * @param unitPrice the new unit price of the item
     */
    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
        this.totalPrice = unitPrice.multiply(new BigDecimal(this.qtyInStock));
    }

    /**
     * Returns the quantity of the item in stock.
     * 
     * @return the quantity of the item in stock
     */
    public int getQtyInStock() {
        return qtyInStock;
    }

    /**
     * Sets the quantity of the item in stock and updates the total price of the item.
     * 
     * @param qtyInStock the new quantity of the item in stock
     */
    public void setQtyInStock(int qtyInStock) {
        this.qtyInStock = qtyInStock;
        this.totalPrice = this.unitPrice.multiply(new BigDecimal(qtyInStock));
    }

    /**
     * Returns the total price of the item.
     * 
     * @return the total price of the item
     */
    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    /**
     * Returns a string representation of the item.
*
* @return a string representation of the item
*/
public String toString() {
    return "ID: " + id + ", Description: " + description + ", Unit Price: " + unitPrice + ", Quantity in Stock: " + qtyInStock + ", Total Price: " + totalPrice;
    }
    


//Unit tests

public void testConstructorAndGetters() {
    Item item = new Item(1, "item 1", new BigDecimal("10.00"), 5);
    assertEquals(1, item.getId());
    assertEquals("item 1", item.getDescription());
    assertEquals(new BigDecimal("10.00"), item.getUnitPrice());
    assertEquals(5, item.getQtyInStock());
    assertEquals(new BigDecimal("50.00"), item.getTotalPrice());
}


private void assertEquals(String string, String description2) {
}

private void assertEquals(int i, Integer id2) {
}

public void testSetters() {
    Item item = new Item(1, "item 1", new BigDecimal("10.00"), 5);
    item.setDescription("new description");
    assertEquals("new description", item.getDescription());
    item.setUnitPrice(new BigDecimal("12.50"));
    assertEquals(new BigDecimal("12.50"), item.getUnitPrice());
    assertEquals(new BigDecimal("62.50"), item.getTotalPrice());
    item.setQtyInStock(10);
    assertEquals(10, item.getQtyInStock());
    assertEquals(new BigDecimal("125.00"), item.getTotalPrice());
}


private void assertEquals(BigDecimal bigDecimal, BigDecimal totalPrice2) {
}

public void testToString() {
    Item item = new Item(1, "item 1", new BigDecimal("10.00"), 5);
    assertEquals("ID: 1, Description: item 1, Unit Price: 10.00, Quantity in Stock: 5, Total Price: 50.00", item.toString());
}


public void testInvalidInput() {
    assertThrows(IllegalArgumentException.class, () -> {
        Item item = new Item(0, "item 1", new BigDecimal("10.00"), 5);
    });
    assertThrows(IllegalArgumentException.class, () -> {
        Item item = new Item(1, null, new BigDecimal("10.00"), 5);
    });
    assertThrows(IllegalArgumentException.class, () -> {
        Item item = new Item(1, "item 1", null, 5);
    });
    assertThrows(IllegalArgumentException.class, () -> {
        Item item = new Item(1, "item 1", new BigDecimal("10.00"), -5);
    });
}


}
