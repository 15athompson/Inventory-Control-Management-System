import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ItemManagerTest {
    private static final String FILE_NAME = "test_items.txt";

    @BeforeEach
    public void setup() throws IOException {
        // Create test file with items
        List<String> lines = Arrays.asList(
                "1,Blue T-Shirt,19.99,50,999.50",
                "2,Black Jeans,49.99,30,1499.70",
                "3,White Sneakers,39.99,25,999.75",
                "4,Red Hoodie,29.99,40,1199.60",
                "5,Green Shorts,14.99,20,299.80"
        );
        Files.write(Path.of(FILE_NAME), lines);
    }

    @Test
    public void testRemoveItem() throws IOException {
        // Create item list
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item(1, "Blue T-Shirt", new BigDecimal("19.99"), 50, new BigDecimal("999.50")));
        items.add(new Item(2, "Black Jeans", new BigDecimal("49.99"), 30, new BigDecimal("1499.70")));
        items.add(new Item(3, "White Sneakers", new BigDecimal("39.99"), 25, new BigDecimal("999.75")));
        items.add(new Item(4, "Red Hoodie", new BigDecimal("29.99"), 40, new BigDecimal("1199.60")));
        items.add(new Item(5, "Green Shorts", new BigDecimal("14.99"), 20, new BigDecimal("299.80")));

        // Remove item 3
        System.setIn(new java.io.ByteArrayInputStream("3\n".getBytes()));
        ItemManager.removeItem(items, FILE_NAME);
        ArrayList<Item> expectedItems = new ArrayList<>(items);
        expectedItems.remove(2); // Remove item at index 2 (item 3)
        Assertions.assertEquals(expectedItems, items);

        // Remove item 1
        System.setIn(new java.io.ByteArrayInputStream("1\n".getBytes()));
        ItemManager.removeItem(items, FILE_NAME);
        expectedItems.remove(0); // Remove item at index 0 (item 1)
        Assertions.assertEquals(expectedItems, items);

        // Try to remove non-existing item
        System.setIn(new java.io.ByteArrayInputStream("10\n".getBytes()));
        ItemManager.removeItem(items, FILE_NAME);
        Assertions.assertEquals(expectedItems, items);
    }

    
    
    
    @Test
    public void testUpdateItem() {
        // Set up test data
        ArrayList<Item> items = new ArrayList<>();
        Item item1 = new Item("1", "Item 1", new BigDecimal("10.00"), 5);
        Item item2 = new Item("2", "Item 2", new BigDecimal("20.00"), 10);
        Item item3 = new Item("3", "Item 3", new BigDecimal("30.00"), 15);
        items.add(item1);
        items.add(item2);
        items.add(item3);
        
        // Test updating an existing item
        String input = "2\nNew description\n25.00\n20\n";
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));
        Store.updateItem(items);
        Assertions.assertEquals("2", items.get(1).getId());
        Assertions.assertEquals("New description", items.get(1).getDescription());
        Assertions.assertEquals(new BigDecimal("25.00"), items.get(1).getUnitPrice());
        Assertions.assertEquals(20, items.get(1).getQtyInStock());
        
        // Test updating with invalid input
        String input2 = "3\nNew description\ninvalid\n20\n";
        System.setIn(new java.io.ByteArrayInputStream(input2.getBytes()));
        Store.updateItem(items);
        Assertions.assertEquals("3", items.get(2).getId());
        Assertions.assertEquals("Item 3", items.get(2).getDescription()); // should not be updated
        Assertions.assertEquals(new BigDecimal("30.00"), items.get(2).getUnitPrice()); // should not be updated
        Assertions.assertEquals(15, items.get(2).getQtyInStock()); // should not be updated
    
    
    /*
     This test case sets up an array list of items and tests the updateItem method with different 
     input values. The first test case simulates updating an existing item in the list and 
     verifies that the item's attributes have been updated correctly. 
     The second test case tests updating an item with invalid input, where the unit price 
     is not a valid number. In this case, the method should not update the item, 
     and the test verifies that the item's attributes have not changed.
     */
    
    }
    
    
    
    public void testAddItem(Object Assertions, List<String> items) {
        // Set up input for the addItem method
        String input = "1\nTest Item\n12.34\n5\n";

        // Set up expected output
        String expectedOutput = "Enter item ID: Enter item description: Enter unit price: Enter quantity in stock: Total price: 61.70\nItem added.\n";

        // Redirect System.in and System.out
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(out));

        // Call the addItem method
        addItem(items);

        // Restore System.in and System.out
        System.setIn(System.in);
        System.setOut(System.out);

        // Check that the item was added to the ArrayList
        ((Object) Assertions).assertEquals(1, items.size());
        String item = items.get(0);
        ((Object) Assertions).assertEquals(1, item.getId());
        ((Object) Assertions).assertEquals("Test Item", item.getDescription());
        ((Object) Assertions).assertEquals(new BigDecimal("12.34"), item.getUnitPrice());
        ((Object) Assertions).assertEquals(5, item.getQtyInStock());
        ((Object) Assertions).assertEquals(new BigDecimal("61.70"), item.getTotalPrice());

        // Check that the addItem method produced the expected output
        Assertions.assertEquals(expectedOutput, out.toString());
    }

    
    public void testAddItemDuplicateId(Object items) {
        // Set up input for the addItem method
        String input = "1\nTest Item 1\n12.34\n5\n2\nTest Item 2\n56.78\n10\n1\nTest Item 3\n90.12\n15\n";

        // Set up expected output
        String expectedOutput = "Enter item ID: Enter item description: Enter unit price: Enter quantity in stock: Total price: 61.70\nItem added.\n" +
                "Enter item ID: Enter item description: Enter unit price: Enter quantity in stock: Total price: 567.80\nItem added.\n" +
                "Enter item ID: Item ID already exists.\n";

        // Redirect System.in and System.out
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(out));

        // Call the addItem method three times with one duplicate ID
        addItem(items);
        addItem(items);
        addItem(items);

        // Restore System.in and System.out
        System.setIn(System.in);
        System.setOut(System.out);

        // Check that only two items were added to the ArrayList
        Assertions.assertEquals(2, items.size());

        // Check that the addItem method produced the expected output
        Assertions.assertEquals(expectedOutput, out.toString());
    }

    
    private void addItem(Object items) {
    }

    public static void main(String[] args) {
        // Test case 1 - Item ID not in list
        ArrayList<Item> items1 = new ArrayList<>();
        items1.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
        items1.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
        searchItem(items1);
        // Input: 10
        // Expected output: "No items found."

        // Test case 2 - Item ID has one result
        ArrayList<Item> items2 = new ArrayList<>();
        items2.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
        items2.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
        searchItem(items2);
        // Input: 1
        // Expected output: "ID Description Unit Price Qty in Stock Total Price\n1 Item 1 10.00 10 100.00"

        // Test case 3 - Item ID has multiple results
        ArrayList<Item> items3 = new ArrayList<>();
        items3.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
        items3.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
        items3.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
        searchItem(items3);
        // Input: 2
        // Expected output: "ID Description Unit Price Qty in Stock Total Price\n2 Item 2 20.00 5 100.00\n2 Item 2 20.00 5 100.00"

        // Test case 4 - Invalid input
        ArrayList<Item> items4 = new ArrayList<>();
        items4.add(new Item(1, "Item 1", new BigDecimal("10.00"), 10));
        items4.add(new Item(2, "Item 2", new BigDecimal("20.00"), 5));
        searchItem(items4);
        // Input: abc
        // Expected output: Exception in thread "main" java.util.InputMismatchException...

        // Test case 5 - Empty list of items
        ArrayList<Item> items5 = new ArrayList<>();
        searchItem(items5);
        // Input: 1
        // Expected output: "No items found."
    }

    private static void searchItem(ArrayList<Item> items2) {
    }

}
 /*

 ---- REMOVE ITEM METHOD -------
  
Test case when item is found and removed:

Input: ArrayList containing items with ids 1, 2, and 3.
User input: 2
Expected output: The item with id 2 is removed from the ArrayList and the message "Item removed." is printed to the console.
Test case when item is not found:

Input: ArrayList containing items with ids 1, 3, and 4.
User input: 2
Expected output: The ArrayList remains unchanged and the message "Item not found." is printed to the console.
Test case when ArrayList is empty:

Input: Empty ArrayList
User input: 1
Expected output: The ArrayList remains empty and the message "Item not found." is printed to the console.
Test case when user input is not an integer:

Input: ArrayList containing items with ids 1, 2, and 3.
User input: "abc"
Expected output: The program throws an InputMismatchException and the ArrayList remains unchanged.

///////////////////////////////

Input and Output scenarios:

Test case 1: Removing item that doesn't exist
Input: 10
Output: No item removed. The list of items should be the same as the original list of items.

Test case 2: Removing item at the beginning of the list
Input: 1
Output: The first item in the list should be removed. The new list should have 4 items instead of 5.

Test case 3: Removing item at the end of the list
Input: 5
Output: The last item in the list should be removed. The new list should have 4 items instead of 5.

Test case 4: Removing item in the middle of the list
Input: 3
Output: The item at index 2 in the list should be removed. The new list should have 4 items instead of 5.

Test case 5: Removing the only item in the list
Input: 1 (assuming the list has only one item with ID 1)
Output: The only item in the list should be removed. The new list should be empty.



/////////////////////////////////


Edge Cases:

Empty input file:
List<String> lines = Collections.emptyList();
Files.write(Path.of(FILE_NAME), lines);

Empty item list:
ArrayList<Item> items = new ArrayList<>();

Remove last item:
System.setIn(new java.io.ByteArrayInputStream("5\n".getBytes()));
ItemManager.removeItem(items, FILE_NAME);
ArrayList<Item> expectedItems = new ArrayList<>(items);
expectedItems.remove(4); // Remove item at index 4 (item 5)
Assertions.assertEquals(expectedItems, items);

Remove first item:
System.setIn(new java.io.ByteArrayInputStream("1\n".getBytes()));
ItemManager.removeItem(items, FILE_NAME);
expectedItems.remove(0); // Remove item at index 0 (item 1)
Assertions.assertEquals(expectedItems, items);

Remove item with negative quantity:
items.add(new Item(6, "Test Item", new BigDecimal("9.99"), -5, new BigDecimal("-49.95")));
System.setIn(new java.io.ByteArrayInputStream("6\n".getBytes()));
ItemManager.removeItem(items, FILE_NAME);
Assertions.assertEquals(expectedItems, items);

Remove item with zero quantity:
items.add(new Item(7, "Test Item", new BigDecimal("9.99"), 0, new BigDecimal("0.00")));
System.setIn(new java.io.ByteArrayInputStream("7\n".getBytes()));
ItemManager.removeItem(items, FILE_NAME);
Assertions.assertEquals(expectedItems, items);

Remove item with non-numeric price:
items.add(new Item(8, "Test Item", new BigDecimal("Not a number"), 10, new BigDecimal("99.90")));
System.setIn(new java.io.ByteArrayInputStream("8\n".getBytes()));
ItemManager.removeItem(items, FILE_NAME);
Assertions.assertEquals(expectedItems, items);

Remove item with non-numeric total value:
items.add(new Item(9, "Test Item", new BigDecimal("19.99"), 5, new BigDecimal("Not a number")));
System.setIn(new java.io.ByteArrayInputStream("9\n".getBytes()));
ItemManager.removeItem(items, FILE_NAME);
Assertions.assertEquals(expectedItems, items);


  */

  /* 
   ------UPDATE ITEM METHOD--------
   Test case for updating item successfully:

Create a new item with id=1, description="Test item", unit price=10.0, quantity in stock=5.
Add the item to an ArrayList of items.
Call the updateItem method with the ArrayList as an argument.
Enter "1" as the ID of the item to update.
Enter "Updated description" as the new description for the item.
Enter "15.0" as the new unit price for the item.
Enter "10" as the new quantity in stock for the item.
Check that the item's description, unit price, and quantity in stock have been updated correctly.
Check that the items.txt file has been updated with the new values.

Test case for entering invalid input for unit price:

Create a new item with id=1, description="Test item", unit price=10.0, quantity in stock=5.
Add the item to an ArrayList of items.
Call the updateItem method with the ArrayList as an argument.
Enter "1" as the ID of the item to update.
Enter "Updated description" as the new description for the item.
Enter "invalid input" as the new unit price for the item.
Check that an error message is displayed indicating that the input is invalid.
Check that the item's description and quantity in stock have not been updated.
Check that the item's unit price has not been updated in both the ArrayList and the items.txt file.

Test case for entering zero for quantity in stock:

Create a new item with id=1, description="Test item", unit price=10.0, quantity in stock=5.
Add the item to an ArrayList of items.
Call the updateItem method with the ArrayList as an argument.
Enter "1" as the ID of the item to update.
Enter "Updated description" as the new description for the item.
Enter "20.0" as the new unit price for the item.
Enter "0" as the new quantity in stock for the item.
Check that an error message is displayed indicating that the input is invalid.
Check that the item's description, unit price, and quantity in stock have not been updated in both the ArrayList and the items.txt file.

Test case for entering empty string for all fields:

Create a new item with id=1, description="Test item", unit price=10.0, quantity in stock=5.
Add the item to an ArrayList of items.
Call the updateItem method with the ArrayList as an argument.
Enter "1" as the ID of the item to update.
Press enter for all the fields.
Check that the item's description, unit price, and quantity in stock have not been updated in both the ArrayList and the items.txt file.
  
/////////////////////////////////

Input and Output scenarios:

Input scenarios:

The user enters the ID of an item that does not exist in the list.
The user enters the ID of an item that exists in the list.
The user enters a non-integer value for the item ID.
The user enters an empty value for the item ID.
The user enters a new description, unit price, and quantity in stock for the itemToUpdate.
The user enters a new description only for the itemToUpdate.
The user enters a new unit price only for the itemToUpdate.
The user enters a new quantity in stock only for the itemToUpdate.
The user enters an invalid input for the new unit price.
The user enters an invalid input for the new quantity in stock.

Output scenarios:

The program outputs "Item not found."
The program prompts the user to enter a new description, unit price, and quantity in stock for the itemToUpdate, updates the item and prints "Item updated: " followed by the updated item's information.
The program outputs "Error: Input was not an integer.".
The program outputs "Enter ID of item to update: ".
The program updates the item and outputs "Item updated: " followed by the updated item's information. It then updates the items.txt file and prints "Item file updated."
The program updates the item's description and outputs "Item updated: " followed by the updated item's information. It then updates the items.txt file and prints "Item file updated."
The program updates the item's unit price and outputs "Item updated: " followed by the updated item's information. It then updates the items.txt file and prints "Item file updated."
The program updates the item's quantity in stock and outputs "Item updated: " followed by the updated item's information. It then updates the items.txt file and prints "Item file updated."
The program outputs "Error: Invalid input for unit price."
The program outputs "Error: Invalid input for quantity in stock."

///////////////////////////////////
Edge Cases:

Update an item with an empty description:

/ Create an item with id 1, description "item1", unit price 10, and quantity in stock 5
Item item1 = new Item("1", "item1", new BigDecimal("10"), 5);

/ Create an ArrayList of items and add the item to it
ArrayList<Item> items = new ArrayList<>();
items.add(item1);

/ Redirect standard input to provide "1\n\n\n" as user input
String input = "1\n\n\n";
InputStream in = new ByteArrayInputStream(input.getBytes());
System.setIn(in);

/ Call the updateItem method
updateItem(items);

Update an item with an invalid unit price:

/ Create an item with id 1, description "item1", unit price 10, and quantity in stock 5
Item item1 = new Item("1", "item1", new BigDecimal("10"), 5);

/ Create an ArrayList of items and add the item to it
ArrayList<Item> items = new ArrayList<>();
items.add(item1);

/ Redirect standard input to provide "1\ninvalid\n\n" as user input
String input = "1\ninvalid\n\n";
InputStream in = new ByteArrayInputStream(input.getBytes());
System.setIn(in);

/ Call the updateItem method
updateItem(items);

Update an item with an invalid quantity in stock:

/ Create an item with id 1, description "item1", unit price 10, and quantity in stock 5
Item item1 = new Item("1", "item1", new BigDecimal("10"), 5);

/ Create an ArrayList of items and add the item to it
ArrayList<Item> items = new ArrayList<>();
items.add(item1);

/ Redirect standard input to provide "1\n\ninvalid\n" as user input
String input = "1\n\ninvalid\n";
InputStream in = new ByteArrayInputStream(input.getBytes());
System.setIn(in);

/ Call the updateItem method
updateItem(items);

Update an item that does not exist:
/ Create an item with id 1, description "item1", unit price 10, and quantity in stock 5
Item item1 = new Item("1", "item1", new BigDecimal("10"), 5);

/ Create an ArrayList of items and add the item to it
ArrayList<Item> items = new ArrayList<>();
items.add(item1);

/ Redirect standard input to provide "2\n" as user input
String input = "2\n";
InputStream in = new ByteArrayInputStream(input.getBytes());
System.setIn(in);

/ Call the updateItem method
updateItem(items);

*/

/*
 ------ ADD ITEM METHOD --------------

Input and Output scenarios:

Input Scenario 1: Valid Input
Enter item ID: 123
Enter item description: Keyboard
Enter unit price: 29.99
Enter quantity in stock: 50

Output Scenario 1:
Total price: 1499.50
Item added.

Input Scenario 2: Item ID Already Exists
Enter item ID: 123
Item ID already exists.

Output Scenario 2:
No item should be added to the ArrayList.

Input Scenario 3: Invalid Unit Price (Negative Value)
Enter item ID: 456
Enter item description: Mouse
Enter unit price: -10
Unit price cannot be negative.
Enter unit price: 15
Enter quantity in stock: 20

Output Scenario 3:
Total price: 300.00
Item added.

Input Scenario 4: Invalid Unit Price (Non-Decimal Value)
Enter item ID: 789
Enter item description: Monitor
Enter unit price: abc
Invalid input. Please enter a valid decimal number.
Enter unit price: 199.99
Enter quantity in stock: 10

Output Scenario 4:
Total price: 1999.90
Item added.
 */