import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;





public class test {
    static String ITEMS_FILE = "items.txt";
    static String TRANSACTIONS_FILE = "transactions.txt";
    



    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        boolean exit = false;

       
       
        System.out.println("I N V E N T O R Y    M A N A G E M E N T    S Y S T E M");
        System.out.println("-----------------------------------------------");

     
       
       
        while (!exit) {
            System.out.println("1. ADD NEW ITEM");
            System.out.println("2. UPDATE QUANTITY OF EXISTING ITEM");
            System.out.println("3. REMOVE ITEM");
            System.out.println("4. SEARCH FOR AN ITEM");
            System.out.println("5. VIEW DAILY TRANSACTION REPORT");
            System.out.println("---------------------------------");
            System.out.println("6. Exit");

            System.out.print("\n Enter a choice and Press ENTER to continue[1-5]: ");
            int userinput = input.nextInt();
            input.nextLine();

            switch (userinput) {

                case 1:
    try {
        String id = "";
boolean isIdValid = false;
boolean isIdUnique = false;

while (!isIdValid && !isIdUnique) {
    System.out.print("Enter item ID: ");
    id = input.nextLine();
    isIdValid = isItemIdValid(id);
    isIdUnique = isItemIdUnique(id);
    if (!isIdValid) {
        System.out.println("Item ID is invalid. Please enter a valid ID.");
    } else if (!isIdUnique) {
        System.out.println("Item ID already exists. Please enter a unique ID.");
    }
}


        String description = "";
        boolean isDescriptionValid = false;
        while (!isDescriptionValid) {
            System.out.print("Enter item description: ");
            description = input.nextLine();
            isDescriptionValid = isItemDescriptionValid(description);
            if (!isDescriptionValid) {
                System.out.println("Item description is invalid. Please enter a valid description.");
            }
        }

        double unitPrice = -1;
        boolean isUnitPriceValid = false;
        while (!isUnitPriceValid) {
            System.out.print("Enter item unit price: ");
            try {
                double inputUnitPrice = Double.parseDouble(input.nextLine());
                if (isItemUnitPriceValid(inputUnitPrice)) {
                    unitPrice = inputUnitPrice;
                    isUnitPriceValid = true;
                } else {
                    System.out.println("Item unit price is invalid. Please enter a valid unit price.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid unit price.");
            }
        }

        int quantity = -1;
        boolean isQuantityValid = false;
        while (!isQuantityValid) {
            System.out.print("Enter item quantity in stock: ");
            try {
                int inputQuantity = Integer.parseInt(input.nextLine());
                if (isItemQuantityValid(inputQuantity)) {
                    quantity = inputQuantity;
                    isQuantityValid = true;
                } else {
                    System.out.println("Item quantity is invalid. Please enter a valid quantity.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid quantity.");
            }
        }

        

        double totalPrice = unitPrice * quantity;
        System.out.println("Total value of items in stock: £" + totalPrice);

        BufferedWriter itemsWriter = new BufferedWriter(new FileWriter(ITEMS_FILE, true));
        itemsWriter.write(id + "," + description + "," + unitPrice + "," + quantity + "\n");
        itemsWriter.close();

        addTransaction(id, 1, quantity, quantity);

        System.out.println("Item added successfully.");
    } catch (IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
    }
    break;




                case 2:
                    try {
                        // code for updating the quantity of an existing item
                        System.out.print("Enter item ID: ");
                        String id = input.nextLine();
                        System.out.print("Enter new quantity: ");
                        int newQty = input.nextInt();

                        BufferedReader itemsReader = new BufferedReader(new FileReader(ITEMS_FILE));
                        StringBuilder itemsData = new StringBuilder();
                        String itemLine;
                        while ((itemLine = itemsReader.readLine()) != null) {
                            String[] itemDetails = itemLine.split(",");
                            if (itemDetails[0].equals(id)) {
                                itemDetails[2] = String.valueOf(newQty);
                                itemLine = String.join(",", itemDetails);
                            }
                            itemsData.append(itemLine).append("\n");
                        }
                        itemsReader.close();

                        BufferedWriter itemsWriter = new BufferedWriter(new FileWriter(ITEMS_FILE));
                        itemsWriter.write(itemsData.toString());
                        itemsWriter.close();

                        int stockRemaining = calculateStockRemaining(id);
                        addTransaction(id, 3, newQty - stockRemaining, stockRemaining);

                        System.out.println("Item updated successfully.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    break;

                case 3:
                    try {
                        // code for removing an item
                        System.out.print("Enter item ID: ");
                        String id = input.nextLine();

                        BufferedReader itemsReader = new BufferedReader(new FileReader(ITEMS_FILE));
                        StringBuilder itemsData = new StringBuilder();
                        String itemLine;
                        while ((itemLine = itemsReader.readLine()) != null) {
                            String[] itemDetails = itemLine.split(",");
                            if (!itemDetails[0].equals(id)) {
                                itemsData.append(itemLine).append("\n");
                            } else {
                                int quantity = Integer.parseInt(itemDetails[2]);
                                double price = Double.parseDouble(itemDetails[3]);
    
                                addTransaction(id, 2, quantity, 0);
    
                                System.out.println("Item removed: " + itemDetails[1]);
                            }
                        }
                        itemsReader.close();
    
                        BufferedWriter itemsWriter = new BufferedWriter(new FileWriter(ITEMS_FILE));
                        itemsWriter.write(itemsData.toString());
                        itemsWriter.close();
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    break;
    
                case 4:
                    try {
                        // code for searching for an item
                        System.out.print("Enter item ID: ");
                        String id = input.nextLine();
    
                        BufferedReader itemsReader = new BufferedReader(new FileReader(ITEMS_FILE));
                        String itemLine;
                        while ((itemLine = itemsReader.readLine()) != null) {
                            String[] itemDetails = itemLine.split(",");
                            if (itemDetails[0].equals(id)) {
                                System.out.println("ID: " + itemDetails[0] + ", Name: " + itemDetails[1] + ", Quantity: "
                                        + itemDetails[2] + ", Price per unit: " + itemDetails[3]);
                                itemsReader.close();
                                break;
                            }
                        }
                        itemsReader.close();
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    break;
    
                case 5:
                    try {
                        // code for viewing the daily transaction report
                        BufferedReader transactionsReader = new BufferedReader(new FileReader(TRANSACTIONS_FILE));
                        String transactionLine;
                        double totalSales = 0.0;
                        while ((transactionLine = transactionsReader.readLine()) != null) {
                            String[] transactionDetails = transactionLine.split(",");
                            String transactionType = "";
                            switch (Integer.parseInt(transactionDetails[1])) {
                                case 1:
                                    transactionType = "Added";
                                    break;
                                case 2:
                                    transactionType = "Removed";
                                    break;
                                case 3:
                                    transactionType = "Updated";
                                    break;
                            }
                            double amount = Integer.parseInt(transactionDetails[3]) * Double.parseDouble(transactionDetails[4]);
                            System.out.println("ID: " + transactionDetails[0] + ", Type: " + transactionType + ", Quantity: " +
                                    transactionDetails[3] + ", Price per unit: " + transactionDetails[4] + ", Amount: " + amount);
                            totalSales += amount;
                        }
                        transactionsReader.close();
                        System.out.println("Total Sales for the day: " + totalSales);
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    break;
    
                case 6:
                    exit = true;
                    break;
    
                default:
                    System.out.println("Invalid choice. Please enter a valid choice [1-6].");
            }
        }
    }


////////////////////////////////////////////////////////

private static boolean isItemIdUnique(String id) {
        return false;
    }




private static boolean isItemIdValid(String id) {
    // Check if the ID is in the format "nnnnn" where n is a digit
    if (!id.matches("\\d{5}")) {
        return false;
    }

    // Check if the ID is in order starting from "00000"
    int num = Integer.parseInt(id);
    return num >= 0 && num <= 99999;
}

    private static boolean isItemQuantityValid(int quantity) {
        return false;
    }

    private static boolean isItemUnitPriceValid(double unitPrice) {
        return false;
    }

    private static boolean isItemDescriptionValid(String description) {
        return false;
    }

    
    

    private static int calculateStockRemaining(String id) {
        return 0;
    }

    private static void addTransaction(String id, int i, int quantity, int quantity2) {
    }

    private static String generateItemId() {
        return null;
    }
}
    
 {
    
}
