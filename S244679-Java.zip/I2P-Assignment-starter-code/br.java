
public class br {

    public static void close() {
    }

}
