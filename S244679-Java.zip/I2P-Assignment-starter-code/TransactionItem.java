
public class TransactionItem {

    public TransactionItem(String itemId, int qty) {
    }

}
