import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Store {
    private static final Statement Database = null;
    private final String tableName = "items";

    public void addItem(Item item) {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO items (id, description, unit_price, qty_in_stock, total_price) VALUES (?, ?, ?, ?, ?)")) {
            ps.setInt(1, item.getId());
            ps.setString(2, item.getDescription());
            ps.setBigDecimal(3, item.getUnitPrice());
            ps.setInt(4, item.getQtyInStock());
            ps.setBigDecimal(5, item.getTotalPrice());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error adding item: " + ex.getMessage());
        }
    }
    
    public void removeItem(int itemId) {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM items WHERE id = ?")) {
            ps.setInt(1, itemId);
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error removing item: " + ex.getMessage());
        }
    }
    
    public void updateItem(Item item) {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE items SET description = ?, unit_price = ?, qty_in_stock = ?, total_price = ? WHERE id = ?")) {
            ps.setString(1, item.getDescription());
            ps.setBigDecimal(2, item.getUnitPrice());
            ps.setInt(3, item.getQtyInStock());
            ps.setBigDecimal(4, item.getTotalPrice());
            ps.setInt(5, item.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error updating item: " + ex.getMessage());
        }
    }
    
    public Object getItem(int itemId) {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM items WHERE id = ?")) {
            ps.setInt(1, itemId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return Item.fromResultSet(rs);
            }
        } catch (SQLException ex) {
            System.out.println("Error getting item: " + ex.getMessage());
        }
        return null;
    }
    
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM items")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                items.add((Item) Item.fromResultSet(rs));
            }
        } catch (SQLException ex) {
            System.out.println("Error getting all items: " + ex.getMessage());
        }
        return items;
    }
}    