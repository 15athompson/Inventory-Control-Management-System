

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Item {
    private static final Statement Database = null;
    private int id;
    private String description;
    private BigDecimal unitPrice;
    private int qtyInStock;
    private BigDecimal totalPrice;

    public Item(int id, String description, BigDecimal unitPrice, int qtyInStock) {
        this.id = id;
        this.description = description;
        this.unitPrice = unitPrice;
        this.qtyInStock = qtyInStock;
        this.totalPrice = unitPrice.multiply(new BigDecimal(qtyInStock));
    }

    public Item(int id, String description, BigDecimal unitPrice, int qtyInStock, BigDecimal totalPrice) {
        this.id = id;
        this.description = description;
        this.unitPrice = unitPrice;
        this.qtyInStock = qtyInStock;
        this.totalPrice = totalPrice;
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
        this.totalPrice = unitPrice.multiply(new BigDecimal(this.qtyInStock));
        updateTotalPrice();
    }

    public int getQtyInStock() {
        return qtyInStock;
    }

    public void setQtyInStock(int qtyInStock) {
        this.qtyInStock = qtyInStock;
        this.totalPrice = this.unitPrice.multiply(new BigDecimal(qtyInStock));
        updateTotalPrice();
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    private void updateTotalPrice() {
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE items SET total_price = ? WHERE id = ?")) {
            ps.setBigDecimal(1, this.totalPrice);
            ps.setInt(2, this.id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error updating total price: " + ex.getMessage());
        }
    }

    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", unitPrice=" + unitPrice +
                ", qtyInStock=" + qtyInStock +
                ", totalPrice=" + totalPrice +
                '}';
    }

    public static Item fromResultSet(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String description = rs.getString("description");
        BigDecimal unitPrice = rs.getBigDecimal("unit_price");
        int qtyInStock = rs.getInt("qty_in_stock");
        BigDecimal totalPrice = rs.getBigDecimal("total_price");
        return new Item(id, description, unitPrice, qtyInStock, totalPrice);
        }
        }
