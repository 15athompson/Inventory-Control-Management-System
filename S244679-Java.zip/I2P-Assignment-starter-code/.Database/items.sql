CREATE TABLE items (
  id INT PRIMARY KEY,
  description VARCHAR(255),
  unit_price DECIMAL(10, 2),
  qty_in_stock INT,
  total_price DECIMAL(10, 2)
);